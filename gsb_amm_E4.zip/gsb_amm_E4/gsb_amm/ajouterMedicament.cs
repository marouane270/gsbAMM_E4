﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gsb_amm
{
    public partial class ajouterMedicament : Form

    {
        
        public ajouterMedicament()
        {
            InitializeComponent();
        }

        private void ajouterMedicament_Load(object sender, EventArgs e)
        {
            tbEffet.Multiline = true;
            tbComposition.Multiline = true;
            tbContreIndication.Multiline = true;
           

            foreach(string code in Globale.lesFamilles.Keys)
            {
                Famille uneFamille = Globale.lesFamilles[code];
                cbFamille.Items.Add(uneFamille.getCode());
            }
        }

        private void btEnregistrer_Click(object sender, EventArgs e)
        {
            
            if (tbComposition.Text != "" && tbContreIndication.Text != "" && tbDepot.Text != "" && tbEffet.Text != "" && tbNomComercial.Text != "")
            {
                int resultatProc = bd.ajouterMedicament(tbDepot.Text, tbNomComercial.Text, tbComposition.Text, tbEffet.Text, tbContreIndication.Text, cbFamille.Text);
                if (resultatProc==1)
                {
                    MessageBox.Show("Le médicament a bien été ajouté ", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Medicament unMedicament = new Medicament(tbDepot.Text, tbNomComercial.Text, tbComposition.Text, tbEffet.Text, tbContreIndication.Text, "", 0, cbFamille.Text);
                    Globale.lesMedicaments.Add(tbDepot.Text, unMedicament);
                }
                else if (resultatProc == 2)
                {
                    MessageBox.Show("Le dépot légal du medicament que vous souhaitez ajouter existe déjà", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (resultatProc==3)
                {
                    MessageBox.Show("Veuillez séléctionner la famille", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("Le système ne réponds pas", "Erreur !", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else MessageBox.Show("Veuillez remplir tous les champs");
        }
    }
}
