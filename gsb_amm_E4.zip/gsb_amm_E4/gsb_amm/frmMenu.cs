﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gsb_amm
{
    public partial class frmMenu1 : Form
    {
        public frmMenu1()
        {
            InitializeComponent();
        }
    private void frmMenu_Load(object sender, EventArgs e)
        {
            //Connexion à la base de données
            Globale.cnx = new System.Data.SqlClient.SqlConnection();
            Globale.cnx.ConnectionString = "Data Source=HPG6-18\\SQLEXPRESS;Initial Catalog=GSB_gesAMM;Integrated Security=True;MultipleActiveResultSets=True";
            Globale.cnx.Open();

            Globale.lesFamilles = new Dictionary<string, Famille>();
            Globale.lesMedicaments = new Dictionary<string, Medicament>();
            Globale.lesEtapes = new List<Etape>();
            Globale.lesDecisions = new List<Decision>();

            bd.donnerLeMedicament();
            bd.donnerLaFamille();
            bd.prc_listeDecision();
            bd.prc_listeEtape();
            

        }
        private void ajouterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ajouterMedicament newFrm = new ajouterMedicament();
            newFrm.MdiParent = this;
            newFrm.Show();
        }

        private void workflowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            workflowMedicament newFrm = new workflowMedicament();
            newFrm.MdiParent = this;
            newFrm.Show();
        }
    }
}
