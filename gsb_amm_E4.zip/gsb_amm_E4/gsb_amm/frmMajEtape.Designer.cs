﻿namespace gsb_amm
{
    partial class frmMajEtape
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstEtapeNormees = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bt_MAJ = new System.Windows.Forms.Button();
            this.dateMAJ = new System.Windows.Forms.DateTimePicker();
            this.tbNorme2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbNorme1 = new System.Windows.Forms.Label();
            this.cbEtapeN = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstEtapeNormees
            // 
            this.lstEtapeNormees.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.lstEtapeNormees.Location = new System.Drawing.Point(15, 122);
            this.lstEtapeNormees.Name = "lstEtapeNormees";
            this.lstEtapeNormees.Size = new System.Drawing.Size(562, 266);
            this.lstEtapeNormees.TabIndex = 0;
            this.lstEtapeNormees.UseCompatibleStateImageBehavior = false;
            this.lstEtapeNormees.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "numero de l\'etape";
            this.columnHeader1.Width = 139;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "libelle";
            this.columnHeader2.Width = 81;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "norme";
            this.columnHeader3.Width = 133;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "date Normee";
            this.columnHeader4.Width = 128;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(196, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Liste des étapes Normée";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Selectionner etape:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.bt_MAJ);
            this.groupBox1.Controls.Add(this.dateMAJ);
            this.groupBox1.Controls.Add(this.tbNorme2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tbNorme1);
            this.groupBox1.Controls.Add(this.cbEtapeN);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(697, 62);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(355, 338);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Mise a jour d\'une etape";
            // 
            // bt_MAJ
            // 
            this.bt_MAJ.Location = new System.Drawing.Point(99, 274);
            this.bt_MAJ.Name = "bt_MAJ";
            this.bt_MAJ.Size = new System.Drawing.Size(155, 38);
            this.bt_MAJ.TabIndex = 11;
            this.bt_MAJ.Text = "Mettre a jour";
            this.bt_MAJ.UseVisualStyleBackColor = true;
            this.bt_MAJ.Click += new System.EventHandler(this.bt_MAJ_Click);
            // 
            // dateMAJ
            // 
            this.dateMAJ.Location = new System.Drawing.Point(129, 212);
            this.dateMAJ.Name = "dateMAJ";
            this.dateMAJ.Size = new System.Drawing.Size(200, 24);
            this.dateMAJ.TabIndex = 10;
            // 
            // tbNorme2
            // 
            this.tbNorme2.Location = new System.Drawing.Point(179, 149);
            this.tbNorme2.Name = "tbNorme2";
            this.tbNorme2.Size = new System.Drawing.Size(121, 24);
            this.tbNorme2.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 18);
            this.label5.TabIndex = 8;
            this.label5.Text = "Nouvel Date:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 149);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 18);
            this.label4.TabIndex = 7;
            this.label4.Text = "Nouvel Norme:";
            // 
            // tbNorme1
            // 
            this.tbNorme1.AutoSize = true;
            this.tbNorme1.Location = new System.Drawing.Point(19, 115);
            this.tbNorme1.Name = "tbNorme1";
            this.tbNorme1.Size = new System.Drawing.Size(0, 18);
            this.tbNorme1.TabIndex = 5;
            // 
            // cbEtapeN
            // 
            this.cbEtapeN.FormattingEnabled = true;
            this.cbEtapeN.Location = new System.Drawing.Point(179, 78);
            this.cbEtapeN.Name = "cbEtapeN";
            this.cbEtapeN.Size = new System.Drawing.Size(121, 26);
            this.cbEtapeN.TabIndex = 3;
            // 
            // frmMajEtape
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1191, 501);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstEtapeNormees);
            this.Name = "frmMajEtape";
            this.Text = "frmMajEtape";
            this.Load += new System.EventHandler(this.frmMajEtape_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lstEtapeNormees;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbEtapeN;
        private System.Windows.Forms.DateTimePicker dateMAJ;
        private System.Windows.Forms.TextBox tbNorme2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label tbNorme1;
        private System.Windows.Forms.Button bt_MAJ;
    }
}