﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gsb_amm
{
    public partial class FrmSaisiDesicion : Form
    {
        public FrmSaisiDesicion()
        {
            InitializeComponent();
        }

        private void chargerCB()
        {
            

            foreach(string code in Globale.lesMedicaments.Keys)
            {
                Medicament unMedicament = Globale.lesMedicaments[code];
                cbMedicament.Items.Add(unMedicament.getDepotLegal());
            }
        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            lvDecision.Items.Clear();
            string code = cbMedicament.Text;
            
            
            string EtpLibelle = "";
            string EtpDate;
            
            Medicament unMedicament = Globale.lesMedicaments[code];


            foreach (Workflow unWrf in unMedicament.getWorkflow())
            {
                ListViewItem maLigne = new ListViewItem();
                maLigne.Text = unWrf.getNumEtape().ToString();
                maLigne.SubItems.Add(unWrf.getDateDecision().ToShortDateString());
                foreach (Etape lEtape in Globale.lesEtapes)
                {

                    if (unWrf.getNumEtape() == lEtape.getNumero())
                    {
                        

                        maLigne.SubItems.Add(lEtape.getLibelle());
                        if (lEtape.GetType().Name == "etapeNormee")
                        {
                            EtpLibelle = (lEtape as etapeNormee).getLibelleNorme();
                            EtpDate = (lEtape as etapeNormee).getDateNorme().ToShortDateString();
                            maLigne.SubItems.Add(EtpDate);
                            maLigne.SubItems.Add(EtpLibelle);
                            

                        }
                        lvDecision.Items.Add(maLigne);
                    }
                    else { }
                }

            }
            
        }

        private void FrmSaisiDesicion_Load(object sender, EventArgs e)
        {
            chargerCB();
            groupBox2.Visible = false;
            

        }

        private void label2_Click(object sender, EventArgs e)
        {
        }
        private void lvDecision_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void btValider_Click(object sender, EventArgs e)
        {
            
            
            if (dateTimePicker1.Text == "" || lvDecisionSuiv.Items == null )
            {
                MessageBox.Show("Veillez renseigner tous les champs");
            }
            else
            {


                    if (rbAcceptee.Checked)
                    {
                        Medicament unMedi = Globale.lesMedicaments[cbMedicament.Text];

                        unMedi.ajouterWorkflow(DateTime.Parse(dateTimePicker1.Text), unMedi.getDerniereEtape() + 1 , 1);
                        bd.InsertWorkflow(dateTimePicker1.Value, unMedi.getDerniereEtape() + 1, 1, cbMedicament.Text);
                        unMedi.setDerniereEtp(unMedi.getDerniereEtape() + 1);
                        MessageBox.Show("Le medicament a été accepté pour l'étape suivante");
                    }
                    else
                    {
                        Medicament unMedi = Globale.lesMedicaments[cbMedicament.Text];
                        unMedi.ajouterWorkflow(DateTime.Parse(dateTimePicker1.Text), unMedi.getDerniereEtape() + 1 , 2);
                        bd.InsertWorkflow(dateTimePicker1.Value, unMedi.getDerniereEtape() + 1, 2, cbMedicament.Text);
                        unMedi.setDerniereEtp(unMedi.getDerniereEtape() + 1);
                        MessageBox.Show("Le medicament a été refusé pour l'étape suivante");
                    }
                
            }
        }

        private void btEtpSuiv_Click(object sender, EventArgs e)
        {
            lvDecisionSuiv.Items.Clear();
            // recup du médi
            string code = cbMedicament.Text;
            //recherche derniere etape médi

            Medicament unMedicament = Globale.lesMedicaments[code];
            int etp2 = 0;
            int etpSuiv = 0;
            Boolean erreur = false;
            etp2 = unMedicament.getDerniereEtape();
            if (etp2 == 0)
            {
                etpSuiv = 1;
            }
            else
            {

                if (etp2 < 8)
                {
                    Workflow unWorkfl = unMedicament.getWorkflow().ElementAt(etp2 - 1);
                    if (unWorkfl.getIdDecision() == 2)
                    {
                        erreur = true;
                        MessageBox.Show("L'etape précedante a été refusée");
                    }
                }
                else
                {
                    erreur = true;
                    MessageBox.Show("L'etape 8 est deja atteinte");
                }
            }


                if(erreur == false)
                {
                    groupBox2.Visible = true;
                    int idx = 0;
                    bool trouve = false;
                    Etape uneEtp;
                    etpSuiv = etp2 + 1;
                    string EtpLibelle = "";
                    while (idx < Globale.lesEtapes.Count() && !trouve)
                    {
                        uneEtp = Globale.lesEtapes.ElementAt(idx);

                        if (etpSuiv == uneEtp.getNumero())
                        {
                            trouve = true;
                            ListViewItem maLigne = new ListViewItem();
                            maLigne.Text = etpSuiv.ToString();

                            maLigne.SubItems.Add(uneEtp.getLibelle());
                            if (uneEtp.GetType().Name == "etapeNormee")
                            {
                                EtpLibelle = (uneEtp as etapeNormee).getLibelleNorme();
                                maLigne.SubItems.Add(EtpLibelle);


                            }
                            lvDecisionSuiv.Items.Add(maLigne);

                        }
                        else { idx++; }
                    }

                }

              
        }
    }
}
