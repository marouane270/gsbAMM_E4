﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gsb_amm
{
    class Utilisateur
    {
        private int idUtil;
        private string nom;
        private string prenom;
        private string login;
        private string mdp;

        public Utilisateur(int lUtil, string leNom, string lePrenom, string leLogin, string leMDP)
        {
            this.idUtil = lUtil;
            this.nom = leNom;
            this.prenom = lePrenom;
            this.login = leLogin;
            this.mdp = leMDP;
        }

        public string getNom() { return this.nom; }
        public string getLogin() { return this.login; }
        public string getMDP() { return this.mdp; }
    }
}
