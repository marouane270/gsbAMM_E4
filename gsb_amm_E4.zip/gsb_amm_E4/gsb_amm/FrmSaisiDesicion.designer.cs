﻿namespace gsb_amm
{
    partial class FrmSaisiDesicion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbMedicament = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btAfficher = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbRefusee = new System.Windows.Forms.RadioButton();
            this.rbAcceptee = new System.Windows.Forms.RadioButton();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lvDecisionSuiv = new System.Windows.Forms.ListView();
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btValider = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lvDecision = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btEtpSuiv = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbMedicament
            // 
            this.cbMedicament.FormattingEnabled = true;
            this.cbMedicament.Location = new System.Drawing.Point(161, 68);
            this.cbMedicament.Name = "cbMedicament";
            this.cbMedicament.Size = new System.Drawing.Size(191, 24);
            this.cbMedicament.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Médicament :";
            // 
            // btAfficher
            // 
            this.btAfficher.Location = new System.Drawing.Point(359, 65);
            this.btAfficher.Name = "btAfficher";
            this.btAfficher.Size = new System.Drawing.Size(156, 29);
            this.btAfficher.TabIndex = 2;
            this.btAfficher.Text = "Afficher";
            this.btAfficher.UseVisualStyleBackColor = true;
            this.btAfficher.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbRefusee);
            this.groupBox2.Controls.Add(this.rbAcceptee);
            this.groupBox2.Controls.Add(this.dateTimePicker1);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.lvDecisionSuiv);
            this.groupBox2.Controls.Add(this.btValider);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(580, 65);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(636, 375);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // rbRefusee
            // 
            this.rbRefusee.AutoSize = true;
            this.rbRefusee.Location = new System.Drawing.Point(438, 236);
            this.rbRefusee.Name = "rbRefusee";
            this.rbRefusee.Size = new System.Drawing.Size(89, 21);
            this.rbRefusee.TabIndex = 7;
            this.rbRefusee.TabStop = true;
            this.rbRefusee.Text = "Refusée";
            this.rbRefusee.UseVisualStyleBackColor = true;
            // 
            // rbAcceptee
            // 
            this.rbAcceptee.AutoSize = true;
            this.rbAcceptee.Location = new System.Drawing.Point(308, 236);
            this.rbAcceptee.Name = "rbAcceptee";
            this.rbAcceptee.Size = new System.Drawing.Size(96, 21);
            this.rbAcceptee.TabIndex = 6;
            this.rbAcceptee.TabStop = true;
            this.rbAcceptee.Text = "Acceptée";
            this.rbAcceptee.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(322, 191);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(224, 22);
            this.dateTimePicker1.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(132, 238);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(142, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "Type de décision :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(132, 196);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(158, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Date de la décision :";
            // 
            // lvDecisionSuiv
            // 
            this.lvDecisionSuiv.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8});
            this.lvDecisionSuiv.Location = new System.Drawing.Point(29, 21);
            this.lvDecisionSuiv.Name = "lvDecisionSuiv";
            this.lvDecisionSuiv.Size = new System.Drawing.Size(599, 135);
            this.lvDecisionSuiv.TabIndex = 2;
            this.lvDecisionSuiv.UseCompatibleStateImageBehavior = false;
            this.lvDecisionSuiv.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "n°";
            this.columnHeader6.Width = 125;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "libelle";
            this.columnHeader7.Width = 111;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Reference Norme";
            this.columnHeader8.Width = 168;
            // 
            // btValider
            // 
            this.btValider.Location = new System.Drawing.Point(335, 286);
            this.btValider.Name = "btValider";
            this.btValider.Size = new System.Drawing.Size(180, 29);
            this.btValider.TabIndex = 1;
            this.btValider.Text = "Valider";
            this.btValider.UseVisualStyleBackColor = true;
            this.btValider.Click += new System.EventHandler(this.btValider_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(132, 292);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Etape Suivante :";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // lvDecision
            // 
            this.lvDecision.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.lvDecision.Location = new System.Drawing.Point(27, 117);
            this.lvDecision.Name = "lvDecision";
            this.lvDecision.Size = new System.Drawing.Size(546, 245);
            this.lvDecision.TabIndex = 0;
            this.lvDecision.UseCompatibleStateImageBehavior = false;
            this.lvDecision.View = System.Windows.Forms.View.Details;
            this.lvDecision.SelectedIndexChanged += new System.EventHandler(this.lvDecision_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "n°";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "date ";
            this.columnHeader2.Width = 83;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "libellé";
            this.columnHeader3.Width = 111;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Date norme";
            this.columnHeader4.Width = 99;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Norme";
            this.columnHeader5.Width = 118;
            // 
            // btEtpSuiv
            // 
            this.btEtpSuiv.Location = new System.Drawing.Point(197, 368);
            this.btEtpSuiv.Name = "btEtpSuiv";
            this.btEtpSuiv.Size = new System.Drawing.Size(173, 54);
            this.btEtpSuiv.TabIndex = 5;
            this.btEtpSuiv.Text = "Passer à l\'étape suivante ";
            this.btEtpSuiv.UseVisualStyleBackColor = true;
            this.btEtpSuiv.Click += new System.EventHandler(this.btEtpSuiv_Click);
            // 
            // FrmSaisiDesicion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1259, 524);
            this.Controls.Add(this.btEtpSuiv);
            this.Controls.Add(this.lvDecision);
            this.Controls.Add(this.btAfficher);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.cbMedicament);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "FrmSaisiDesicion";
            this.Text = " ";
            this.Load += new System.EventHandler(this.FrmSaisiDesicion_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbMedicament;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btAfficher;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListView lvDecision;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.Button btValider;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rbRefusee;
        private System.Windows.Forms.RadioButton rbAcceptee;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListView lvDecisionSuiv;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.Button btEtpSuiv;
    }
}