﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gsb_amm
{
    class Decision
    {
        int id;
        string libelle;

        public Decision(int leId, string leLibelle)
        {
            this.id = leId;
            this.libelle = leLibelle;
        }

        public int getId() { return this.id; }
        public string getLibelle() { return this.libelle; }
    }
}
