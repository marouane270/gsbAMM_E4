﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace gsb_amm
{
    public static class bd
    {

        public static void prc_listeEtape()
        {
            //objet SQLCommand pour définir la procédure stockée à utiliser
            SqlCommand maRequete = new SqlCommand("prc_listeEtape", Globale.cnx);
            maRequete.CommandType = System.Data.CommandType.StoredProcedure;

            // exécuter la procedure stockée dans un curseur 
            SqlDataReader SqlExec = maRequete.ExecuteReader();
            Etape lEtape = null;
            //boucle de lecture des étapes avec ajout dans la collection
            while (SqlExec.Read())
            {
                int EtapeNum = int.Parse(SqlExec["ETAPE_NUM"].ToString());
                string EtapeLibelle = SqlExec["ETAPE_LIBELLE"].ToString();
                string Norme = SqlExec["ETAPE_NORME"].ToString();
                if (Norme == "")
                {
                    lEtape = new Etape(EtapeNum, EtapeLibelle);
                    
                }
                else
                {
                    DateTime dateNorme = DateTime.Parse(SqlExec["ETAPE_DATE_NORME"].ToString());
                    lEtape = new etapeNormee(EtapeNum, EtapeLibelle, Norme, dateNorme);
                }

                Globale.lesEtapes.Add(lEtape);
            }
            SqlExec.Close();
        }

        
        public static Boolean MAJ_Etape_Norme(string norme, DateTime date, int num)
        {
            SqlCommand maRequete = new SqlCommand("prc_MAJ_Norme", Globale.cnx);
            // Il s’agit d’une procédure stockée:
            maRequete.CommandType = System.Data.CommandType.StoredProcedure;

            // Ajouter les parameters à la procédure stockée
            SqlParameter paramNum = new SqlParameter("@numEtape", System.Data.SqlDbType.Int, 5);
            paramNum.Value = num;
            SqlParameter paramNorme = new SqlParameter("@norme2", System.Data.SqlDbType.VarChar, 20);
            paramNorme.Value = norme;
            SqlParameter paramDate = new SqlParameter("@dateNorme2", System.Data.SqlDbType.Date, 20);
            paramDate.Value = date;

            maRequete.Parameters.Add(paramNum);
            maRequete.Parameters.Add(paramNorme);
            maRequete.Parameters.Add(paramDate);

            // exécuter la procedure stockée
            try
            {
                maRequete.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static void prc_listeDecision()
        {
            
            //objet SQLCommand pour définir la procédure stockée à utiliser
            SqlCommand maRequete = new SqlCommand("prc_listeDecision", Globale.cnx);
            maRequete.CommandType = System.Data.CommandType.StoredProcedure;

            // exécuter la procedure stockée dans un curseur 
            SqlDataReader SqlExec = maRequete.ExecuteReader();
            Decision uneDecision = null;
            //boucle de lecture des décisions avec ajout dans la collection
            while (SqlExec.Read())
            {
                int DcsId = int.Parse(SqlExec["DCS_ID"].ToString());
                string DcsLibelle = SqlExec["DCS_LIBELLE"].ToString();

                uneDecision = new Decision(DcsId, DcsLibelle);

                Globale.lesDecisions.Add(uneDecision);
            }
            SqlExec.Close();
        }


        public static void donnerLeMedicament()
        {
            SqlCommand maRequete = new SqlCommand("prc_donnerMedicament", Globale.cnx);
            maRequete.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataReader SqlExec = maRequete.ExecuteReader();

            while (SqlExec.Read())
            {
                string depotLegal = SqlExec["MED_DEPOTLEGAL"].ToString();
                string nomCmmercial = SqlExec["MED_NOMCOMMERCIAL"].ToString();
                string composition = SqlExec["MED_COMPOSITION"].ToString();
                string effet = SqlExec["MED_EFFETS"].ToString();
                string contreIndic = SqlExec["MED_CONTREINDIC"].ToString();
                string amm = SqlExec["MED_AMM"].ToString();
                string codeFamille = SqlExec["MED_CODEFAMILLE"].ToString();
                int derniereEtape = 0;
                if (SqlExec["MED_DERNIERETAPE"].ToString() != "")
                {
                    derniereEtape = int.Parse(SqlExec["MED_DERNIERETAPE"].ToString());
                }

                Medicament unMedicament = new Medicament(depotLegal, nomCmmercial, composition, effet, contreIndic, amm, derniereEtape, codeFamille);

                SqlCommand maRequete2 = new SqlCommand("prc_DonnerLeMedicamentWorkflow", Globale.cnx);
                maRequete2.CommandType = System.Data.CommandType.StoredProcedure;
                SqlParameter paramIdMedicament = new SqlParameter("@MED_DEPOTLEGAL", System.Data.SqlDbType.NVarChar, 10);
                paramIdMedicament.Value = depotLegal;
                maRequete2.Parameters.Add(paramIdMedicament);
                SqlDataReader SqlExec2 = maRequete2.ExecuteReader();

                while (SqlExec2.Read())
                {
                    DateTime wf_DateDecision = DateTime.Parse(SqlExec2["WF_DATEDECISION"].ToString());
                    int wf_numEtape = int.Parse(SqlExec2["WF_NUMETAPE"].ToString());
                    int wf_idDecision = int.Parse(SqlExec2["WF_DCS_ID"].ToString());

                    unMedicament.ajouterWorkflow(wf_DateDecision, wf_numEtape, wf_idDecision);
                }
                SqlExec2.Close();

                Globale.lesMedicaments.Add(depotLegal, unMedicament);

            }
            SqlExec.Close();

        }


        public static void donnerLaFamille()
        {
            SqlCommand maRequete = new SqlCommand("prc_DonnerLaFamille", Globale.cnx);
            maRequete.CommandType = System.Data.CommandType.StoredProcedure;

            SqlDataReader SqlExec = maRequete.ExecuteReader();

            while (SqlExec.Read())
            {
                string fam_code = SqlExec["FAM_CODE"].ToString();
                string fam_libelle = SqlExec["FAM_LIBELLE"].ToString();
                int fam_nbMediAmm = 0;
                if (SqlExec["FAM_NB_MEDI_AMM"].ToString() != "")
                {
                    fam_nbMediAmm = int.Parse(SqlExec["FAM_NB_MEDI_AMM"].ToString());
                }
                
                Famille uneFamille = new Famille(fam_code, fam_libelle, fam_nbMediAmm);

                Globale.lesFamilles.Add(fam_code, uneFamille);
            }
            SqlExec.Close();

        }

        public static void lireLesUtilisateurs()
        {

            //objet SQLCommand pour définir la procédure stockée à utiliser
            SqlCommand maRequete = new SqlCommand("prc_listeDesUtilisateurs", Globale.cnx);
            maRequete.CommandType = System.Data.CommandType.StoredProcedure;

            // exécuter la procedure stockée dans un curseur 
            SqlDataReader SqlExec = maRequete.ExecuteReader();

            //boucle de lecture des clients avec ajout dans la collection
            while (SqlExec.Read())
            {
                int idUtil = int.Parse(SqlExec["UTIL_ID"].ToString());
                string nom = SqlExec["UTIL_NOM"].ToString();
                string prenom = SqlExec["UTIL_PRENOM"].ToString();
                string login = SqlExec["UTIL_LOGIN"].ToString().Trim();
                string mdp = SqlExec["UTIL_MDP"].ToString().Trim();

                Utilisateur lUtilisateur = new Utilisateur(idUtil, nom, prenom, login, mdp);

                Globale.lesUtilisateurs.Add(lUtilisateur);
            }
            SqlExec.Close();
        }

        public static int ajouterMedicament(string depotLegal, string nomCommercial, string composition, string effet, string contreIndication, string codeFamille)
        {
            SqlCommand maRequete = new SqlCommand("prc_ajouterMedicament", Globale.cnx);
            // Il s’agit d’une procédure stockée:
            maRequete.CommandType = System.Data.CommandType.StoredProcedure;



            SqlParameter paramDepot = new SqlParameter("@MED_DEPOTLEGAL", System.Data.SqlDbType.NVarChar, 10);
            paramDepot.Value = depotLegal;
            SqlParameter paramNomCommercial = new SqlParameter("@MED_NOMCOMMERCIAL", System.Data.SqlDbType.NVarChar, 25);
            paramNomCommercial.Value = nomCommercial;
            SqlParameter paramComposition = new SqlParameter("@MED_COMPOSITION", System.Data.SqlDbType.NVarChar, 255);
            paramComposition.Value = composition;
            SqlParameter paramEffet = new SqlParameter("@MED_EFFETS", System.Data.SqlDbType.NVarChar, 255);
            paramEffet.Value = effet;
            SqlParameter paramContre = new SqlParameter("@MED_CONTREINDIC", System.Data.SqlDbType.NVarChar, 255);
            paramContre.Value = contreIndication;
            SqlParameter paramCodeFamille = new SqlParameter("@MED_CODEFAMILLE", System.Data.SqlDbType.NVarChar, 3);
            paramCodeFamille.Value = codeFamille;
            SqlParameter paramValid = new SqlParameter("@valid", System.Data.SqlDbType.Int);
            paramValid.Direction = System.Data.ParameterDirection.Output;
            maRequete.Parameters.Add(paramDepot);
            maRequete.Parameters.Add(paramNomCommercial);
            maRequete.Parameters.Add(paramComposition);
            maRequete.Parameters.Add(paramEffet);
            maRequete.Parameters.Add(paramContre);
            maRequete.Parameters.Add(paramCodeFamille);
            maRequete.Parameters.Add(paramValid);
            try
            {
                maRequete.ExecuteNonQuery();
                return int.Parse(paramValid.Value.ToString());
            }
            catch
            {
                return 4;
            }
        }

        public static Boolean InsertWorkflow(DateTime date, int numEtape, int typeDsc, string depotLegal)
        {
            SqlCommand maRequete = new SqlCommand("prc_InsertWorkflow", Globale.cnx);
            // Il s’agit d’une procédure stockée:
            maRequete.CommandType = System.Data.CommandType.StoredProcedure;



            // Ajouter les parameters à la procédure stockée
            SqlParameter paramDate = new SqlParameter("@dateDecision", System.Data.SqlDbType.Date, 20);
            paramDate.Value = date;
            SqlParameter paramNum = new SqlParameter("@numEtape", System.Data.SqlDbType.Int, 5);
            paramNum.Value = numEtape;
            SqlParameter paramTypeDsc = new SqlParameter("@typeDecision", System.Data.SqlDbType.Int, 5);
            paramTypeDsc.Value = typeDsc;
            SqlParameter paramDepotL = new SqlParameter("@depotLegal", System.Data.SqlDbType.VarChar, 20);
            paramDepotL.Value = depotLegal;



            maRequete.Parameters.Add(paramDate);
            maRequete.Parameters.Add(paramNum);
            maRequete.Parameters.Add(paramTypeDsc);
            maRequete.Parameters.Add(paramDepotL);


            // exécuter la procedure stockée
            try
            {
                maRequete.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
