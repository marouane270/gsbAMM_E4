﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gsb_amm
{
    class Medicament
    {
        private string depotLegal;
        private string nomCommercial;
        private string composition;
        private string effets;
        private string contreIndication;
        private string amm;
        private int derniereEtape;
        private string codeFamille;
        private List<Workflow> lesEtapesWorkflow;

        public Medicament(string leDepotLegal, string leNomCommercial, string laComposition, string leEffet, string LaContreIndication, string leAmm, int laDerniereEtape, string leCodeFamille)
        {
            this.depotLegal = leDepotLegal;
            this.nomCommercial = leNomCommercial;
            this.composition = laComposition;
            this.effets = leEffet;
            this.contreIndication = LaContreIndication;
            this.amm = leAmm;
            this.derniereEtape = laDerniereEtape;
            this.codeFamille = leCodeFamille;
            this.lesEtapesWorkflow = new List<Workflow>();
        }
        public string getDepotLegal() { return this.depotLegal; }
        public string getNomCommercial() { return this.nomCommercial; }
        public string getComposition() { return this.composition; }
        public string getEffet() { return this.effets; }
        public string getcontreIndication() { return this.contreIndication; }
        public string getAmm() { return this.amm; }
        public int getDerniereEtape() { return this.derniereEtape; }
        public string getCodeFamille() { return this.codeFamille; }
        public List<Workflow> getWorkflow() { return this.lesEtapesWorkflow; }
        public void ajouterWorkflow(DateTime laDateDecision, int numEtape, int leIdDecision)
        {
            Workflow unWorkflow = new Workflow(laDateDecision, numEtape, leIdDecision);
            lesEtapesWorkflow.Add(unWorkflow);
        }
        public void setDerniereEtp(int etp) { this.derniereEtape = etp; }

    }
}
