﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gsb_amm
{
    public partial class workflowMedicament : Form
    {
        public workflowMedicament()
        {
            InitializeComponent();
        }

        private void workflowMedicament_Load(object sender, EventArgs e)
        {
            
            foreach (string depot in Globale.lesMedicaments.Keys)
            {
                Medicament unMedi = Globale.lesMedicaments[depot];

                cbMedi.Items.Add(unMedi.getDepotLegal());
            }
           
        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void btValider_Click(object sender, EventArgs e)
        {
            lvMedi.Items.Clear();

            Medicament unMedi = Globale.lesMedicaments[cbMedi.Text];
            if (unMedi.getWorkflow().Count == 0)
            {
                MessageBox.Show("Il n'y a aucun workflow d'enregistré pour ce médicament", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                foreach (Workflow unWork in unMedi.getWorkflow())
                {
                    Decision uneDecision = Globale.lesDecisions.ElementAt(unWork.getIdDecision() - 1);
                    Etape uneEtape = Globale.lesEtapes.ElementAt(unWork.getNumEtape() - 1);




                    ListViewItem maLigne = new ListViewItem();
                    maLigne.Text = unWork.getNumEtape().ToString();
                    maLigne.SubItems.Add(uneEtape.getLibelle());
                    maLigne.SubItems.Add(unWork.getDateDecision().ToString());
                    maLigne.SubItems.Add(uneDecision.getLibelle());
                    if (uneEtape.GetType().Name == "etapeNormee")
                    {

                        maLigne.SubItems.Add((uneEtape as etapeNormee).getLibelleNorme());
                        maLigne.SubItems.Add((uneEtape as etapeNormee).getDateNorme().ToString());
                    }









                    lvMedi.Items.Add(maLigne);
                }
            }

           


        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
