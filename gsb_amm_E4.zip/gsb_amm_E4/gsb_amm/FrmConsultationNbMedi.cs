﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gsb_amm
{
    public partial class FrmConsultationNbMedi : Form
    {
        public FrmConsultationNbMedi()
        {
            InitializeComponent();
        }

        private void FrmConsultationNbMedi_Load(object sender, EventArgs e)
        {
            foreach (string code in Globale.lesFamilles.Keys)
            {
                Famille uneFamille = Globale.lesFamilles[code] ;
                ListViewItem maLigne = new ListViewItem();
                maLigne.Text = uneFamille.getCode().ToString();
                maLigne.SubItems.Add(uneFamille.getLibelle());
                maLigne.SubItems.Add(uneFamille.getNbMediAmm().ToString());

                lvConsultation.Items.Add(maLigne);

            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            foreach (string code in Globale.lesFamilles.Keys)
            {
                Famille uneF = Globale.lesFamilles[code];
                comboBox1.Items.Add(uneF.getCode());
            }
            
        }

        private void btValider_Click(object sender, EventArgs e)
        {
            lvMediAutorise.Items.Clear();

            

            foreach (string code in Globale.lesMedicaments.Keys)
            {
                
                    Medicament unMedicament = Globale.lesMedicaments[code];


                        if (unMedicament.getCodeFamille() == comboBox1.Text && unMedicament.getAmm() == "1")
                        {

                            ListViewItem maLigne = new ListViewItem();
                            maLigne.Text = unMedicament.getNomCommercial().ToString();
                            maLigne.SubItems.Add(unMedicament.getDepotLegal());
    
                            lvMediAutorise.Items.Add(maLigne);
                        }
                   
            }
            
           
        }
        
    }
}
