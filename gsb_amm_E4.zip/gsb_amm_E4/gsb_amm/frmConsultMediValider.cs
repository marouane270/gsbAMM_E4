﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gsb_amm
{
    public partial class frmConsultMediValider : Form
    {
        public frmConsultMediValider()
        {
            InitializeComponent();
        }

        private void frmConsultMediValider_Load(object sender, EventArgs e)
        {
            //bd.lireLesUtilisateurs();
            
            
            

            /*label1.Text = Globale.lesFamilles.Count().ToString();
            label2.Text = Globale.lesMedicaments.Count().ToString();
            label3.Text = Globale.lesDecisions.Count().ToString();*/

            // on charge la liste des medicament en renseignant sont depot, sa famille et son nom commercial
            foreach(string depot in Globale.lesMedicaments.Keys)
            {
                Medicament unMedicament = Globale.lesMedicaments[depot];
                Famille uneFamille = Globale.lesFamilles[unMedicament.getCodeFamille()];

                if(unMedicament.getAmm() == "")
                {
                    ListViewItem maLigne = new ListViewItem();
                    maLigne.Text = unMedicament.getDepotLegal().ToString();
                    maLigne.SubItems.Add(unMedicament.getNomCommercial());
                    maLigne.SubItems.Add(uneFamille.getLibelle());

                    listView1.Items.Add(maLigne);
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            // on vide la liste des workflow a chaque fois que l'on appuie sur le boutton
            listView2.Items.Clear();

            //on rentre dans une variable code le depot du medicament selectionner par l'utilisateur
            string code = listView1.SelectedItems[0].SubItems[0].Text;
            label4.Text = code;
            int idx = 0;
            Boolean trouve = false;
            Decision uneDsc;
            string Des = "";
            Medicament unMedicament = Globale.lesMedicaments[code];

            // on recherche le workflow dont le depot légale correspond à la variable code
            foreach (Workflow unWrf in unMedicament.getWorkflow())
            {
                ListViewItem maLigne = new ListViewItem();
                maLigne.Text = unWrf.getDateDecision().ToShortDateString();
                maLigne.SubItems.Add(unWrf.getNumEtape().ToString());
                while(idx < Globale.lesDecisions.Count() && !trouve)
                {
                    uneDsc = Globale.lesDecisions.ElementAt(idx);
                    if (unWrf.getIdDecision() == uneDsc.getId())
                    {
                        trouve = true;
                        Des = uneDsc.getLibelle();
                    }
                    else { idx++; }
                }
                if (trouve) { maLigne.SubItems.Add(Des); }
                listView2.Items.Add(maLigne);
                
            }
        }
    }
}
