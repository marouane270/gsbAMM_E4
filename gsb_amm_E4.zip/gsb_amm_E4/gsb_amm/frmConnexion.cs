﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace gsb_amm
{
    public partial class frmConnexion : Form
    {
        public frmConnexion()
        {
            InitializeComponent();
        }

        private void btConnexion_Click(object sender, EventArgs e)
        {
            
            int idx = 0;
            Boolean trouve = false;
            Utilisateur unUtilisateur = null;
            string login = tbLogin.Text;
            string mdp = tbMDP.Text;

            if( login != "" && mdp != "")
            {
                while (idx < Globale.lesUtilisateurs.Count && !trouve)
                {
                    unUtilisateur = Globale.lesUtilisateurs.ElementAt(idx);
                    if (login == unUtilisateur.getLogin() && mdp == unUtilisateur.getMDP())
                    {
                        trouve = true;
                    }
                    else
                    {
                        idx++;
                    }

                }
                if (trouve)
                {
                    if (unUtilisateur.getLogin() == "KARAKUSY")
                    {
                        MessageBox.Show("Bienvenue Mr KARAKUS Yasin");
                        Form1 form2 = new Form1();
                        form2.ShowDialog();
                    }
                    else if (unUtilisateur.getLogin() == "BOUMADAFAM")
                    {
                        MessageBox.Show("Bienvenue Mr Boumadafa Marouane");
                        FrmMenuM form2 = new FrmMenuM();
                        form2.ShowDialog();
                    }
                    else if (unUtilisateur.getLogin() == "NAZILI")
                    {
                        MessageBox.Show("Bienvenue Mr Nazil lyes");
                        frmMenu1 form2 = new frmMenu1();
                        form2.ShowDialog();
                        

                    
                    }
                }
                else
                {
                    MessageBox.Show("ERREUR");
                }
            }
            else { MessageBox.Show("info manquante"); }
            
        }

        private void frmConnexion_Load(object sender, EventArgs e)
        {
            Globale.cnx = new System.Data.SqlClient.SqlConnection();
            Globale.cnx.ConnectionString = "Data Source=HPG6-18\\SQLEXPRESS;Initial Catalog=GSB_gesAMM;Integrated Security=True;MultipleActiveResultSets=True";
            Globale.cnx.Open();

            Globale.lesUtilisateurs = new List<Utilisateur>();
            bd.lireLesUtilisateurs();
            
        }
    }
}
