﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gsb_amm
{
    public partial class FrmMenuM : Form
    {
        public FrmMenuM()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Connexion à la base de données
            Globale.cnx = new System.Data.SqlClient.SqlConnection();
            Globale.cnx.ConnectionString = "Data Source=HPG6-18\\SQLEXPRESS;Initial Catalog=GSB_gesAMM;Integrated Security=True;MultipleActiveResultSets=True";
            Globale.cnx.Open();


            Globale.lesMedicaments = new Dictionary<string, Medicament>();
            Globale.lesFamilles = new Dictionary<string, Famille>();
            Globale.lesDecisions = new List<Decision>();
            Globale.lesEtapes = new List<Etape>();
            Globale.lesUtilisateurs = new List<Utilisateur>();

            bd.donnerLaFamille();
            bd.donnerLeMedicament();
            bd.lireLesUtilisateurs();
            bd.prc_listeDecision();
            bd.prc_listeEtape();
            



        }

        private void fichierToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void saisirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmSaisiDesicion newFrm = new FrmSaisiDesicion();
            newFrm.MdiParent = this;
            newFrm.Show();
        }

        private void nbMédicamentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmConsultationNbMedi newFrm = new FrmConsultationNbMedi();
            newFrm.MdiParent = this;
            newFrm.Show();
        }
    }
}
