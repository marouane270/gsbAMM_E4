﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace gsb_amm
{
    public partial class frmMajEtape : Form
    {
        public frmMajEtape()
        {
            InitializeComponent();
        }

        //fonction permettant de vider la listeView et la classe Etape pour ensuite la recharger avec les nouvelles modifications
        private void chargerListe()
        {
            lstEtapeNormees.Items.Clear();
            Globale.lesEtapes.Clear();
            bd.prc_listeEtape();

            foreach (Etape uneEtape in Globale.lesEtapes)
            {
                if(uneEtape.GetType().Name == "etapeNormee")
                {
                    
                    ListViewItem maLigne = new ListViewItem();
                    maLigne.Text = (uneEtape as etapeNormee).getNumero().ToString();
                    maLigne.SubItems.Add((uneEtape as etapeNormee).getLibelle());
                    maLigne.SubItems.Add((uneEtape as etapeNormee).getLibelleNorme());
                    maLigne.SubItems.Add((uneEtape as etapeNormee).getDateNorme().ToString());
                    lstEtapeNormees.Items.Add(maLigne);
                    cbEtapeN.Items.Add((uneEtape as etapeNormee).getNumero());
                }
                
            }
        }
        private void frmMajEtape_Load(object sender, EventArgs e)
        {
            chargerListe();
        }

        private void bt_MAJ_Click(object sender, EventArgs e)
        {
            int idx = 0;
            Boolean trouve = false;
            Etape uneEtape;
            int etape;
            string norme1;
            DateTime date1;

            //on verifie que les champs obligatoire soit renseigner
            if (tbNorme2.Text != "" && dateMAJ.Text != "")
            {
                //on verifie que la modification c'est bien effectuer
                while(idx < Globale.lesEtapes.Count() && !trouve)
                {
                    uneEtape = Globale.lesEtapes.ElementAt(idx);
                    etape = int.Parse(cbEtapeN.Text);
                    norme1 = tbNorme2.Text;
                    date1 = dateMAJ.Value;
                    if (bd.MAJ_Etape_Norme(norme1, date1, etape))
                    {
                        trouve = true;
                        
                    }
                    else
                    {
                        idx++;
                        
                    }


                }

                if (trouve)
                {

                    MessageBox.Show("L'étape a bien été modifier");
                    chargerListe();
                    
                }
                else { MessageBox.Show("Erreur dans la modification de l'étape"); } 
                    
                
                
            }
            else
            {
                MessageBox.Show("Erreur, il faut renseigner tous les champs");
            }
            
        }
    }
}
