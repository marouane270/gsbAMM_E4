﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gsb_amm
{
    class Workflow
    {
        private DateTime dateDecision;
        private int numEtape;
        private int idDecision;

        public Workflow(DateTime laDateDecision, int leNumEtape, int leIdDecision)
        {
            this.dateDecision = laDateDecision;
            this.numEtape = leNumEtape;
            this.idDecision = leIdDecision;
        }
        public DateTime getDateDecision() { return this.dateDecision; }
        public int getNumEtape() { return this.numEtape; }
        public int getIdDecision() { return this.idDecision; }
    }
}
