﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace gsb_amm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void miseAJourEtapeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMajEtape form1 = new frmMajEtape();
            form1.MdiParent = this;
            form1.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Globale.cnx = new System.Data.SqlClient.SqlConnection();
            Globale.cnx.ConnectionString = "Data Source=HPG6-18\\SQLEXPRESS;Initial Catalog=GSB_gesAMM;Integrated Security=True;MultipleActiveResultSets=True";
            Globale.cnx.Open();

            

            Globale.lesEtapes = new List<Etape>();
            Globale.lesDecisions = new List<Decision>();
            Globale.lesFamilles = new Dictionary<string, Famille>();
            Globale.lesMedicaments = new Dictionary<string, Medicament>();

            bd.prc_listeEtape();
            bd.prc_listeDecision();
            bd.donnerLaFamille();
            bd.donnerLeMedicament();
            
        }

        private void consultationDesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmConsultMediValider form1 = new frmConsultMediValider();
            form1.MdiParent = this;
            form1.Show();
        }
    }
}
